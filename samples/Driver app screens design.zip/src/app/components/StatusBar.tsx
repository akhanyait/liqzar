import { Wifi, Battery, Signal } from "lucide-react";

export function StatusBar() {
  const currentTime = new Date().toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: false 
  });

  return (
    <div className="flex items-center justify-between px-6 pt-3 pb-2 text-white">
      <span className="text-sm font-semibold">{currentTime}</span>
      <div className="flex items-center gap-2">
        <Signal className="w-4 h-4" />
        <Wifi className="w-4 h-4" />
        <Battery className="w-4 h-4" />
      </div>
    </div>
  );
}