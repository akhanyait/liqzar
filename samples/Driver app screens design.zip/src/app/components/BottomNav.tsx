import { Home, Package, Bell, BarChart3, User } from "lucide-react";
import { useNavigate, useLocation } from "react-router";
import { useNotifications } from "../context/NotificationContext";

export function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { unreadCount } = useNotifications();
  
  const navItems = [
    { icon: Home, label: "Home", path: "/" },
    { icon: Package, label: "Orders", path: "/orders" },
    { icon: Bell, label: "Alerts", path: "/notifications", badge: unreadCount },
    { icon: BarChart3, label: "Stats", path: "/stats" },
    { icon: User, label: "Profile", path: "/profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-[#1a1a1a]/98 backdrop-blur-lg border-t border-[#3a3a3a] px-4 py-3 z-50">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center gap-1.5 py-2 px-3 min-w-[60px] group relative"
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                isActive 
                  ? 'bg-gradient-to-br from-[#F59E0B] to-[#D97706] shadow-lg shadow-[#F59E0B]/30' 
                  : 'bg-transparent group-hover:bg-[#2a2a2a]'
              }`}>
                <Icon 
                  className={`w-5 h-5 transition-colors ${isActive ? 'text-white' : 'text-gray-500 group-hover:text-gray-300'}`}
                  strokeWidth={isActive ? 2.5 : 2}
                />
              </div>
              {item.badge && item.badge > 0 && (
                <div className="absolute top-1 right-2 bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                  {item.badge}
                </div>
              )}
              <span className={`text-xs transition-colors ${isActive ? 'text-white font-semibold' : 'text-gray-500 group-hover:text-gray-300'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}