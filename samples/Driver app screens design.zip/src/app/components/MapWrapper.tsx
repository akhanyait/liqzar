import { lazy, Suspense } from 'react';

const MapboxMap = lazy(() => import('./MapboxMap').then(module => ({ default: module.MapboxMap })));

interface MapWrapperProps {
  currentLocation: [number, number];
  destination: [number, number];
  route?: any;
}

export function MapWrapper(props: MapWrapperProps) {
  return (
    <Suspense fallback={
      <div className="w-full h-full bg-gradient-to-br from-gray-800 via-gray-900 to-black flex items-center justify-center">
        <div className="text-white text-sm">Loading map...</div>
      </div>
    }>
      <MapboxMap {...props} />
    </Suspense>
  );
}
