import { useEffect, useRef, useState } from 'react';
import Map, { Marker, Source, Layer, NavigationControl } from 'react-map-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { MapPin } from 'lucide-react';

const MAPBOX_TOKEN = "pk.eyJ1IjoiYWtoYW55YWl0IiwiYSI6ImNtbXFyN2wxdzBtMjMycHNiZWJ6OWt5b28ifQ.J2EnpgwudAprvYbMiZCWoQ";

interface MapboxMapProps {
  currentLocation: [number, number];
  destination: [number, number];
  route?: any;
}

export function MapboxMap({ currentLocation, destination, route }: MapboxMapProps) {
  const mapRef = useRef<any>(null);
  const [mapLoaded, setMapLoaded] = useState(false);

  useEffect(() => {
    if (mapRef.current && currentLocation && destination && mapLoaded) {
      try {
        const map = mapRef.current.getMap();
        const bounds = [
          [Math.min(currentLocation[0], destination[0]), Math.min(currentLocation[1], destination[1])],
          [Math.max(currentLocation[0], destination[0]), Math.max(currentLocation[1], destination[1])]
        ];
        map.fitBounds(bounds, { padding: 80, duration: 1000 });
      } catch (error) {
        console.error('Error fitting bounds:', error);
      }
    }
  }, [currentLocation, destination, mapLoaded]);

  const routeGeoJSON = {
    type: 'Feature',
    properties: {},
    geometry: {
      type: 'LineString',
      coordinates: route || [currentLocation, destination]
    }
  };

  return (
    <Map
      ref={mapRef}
      mapboxAccessToken={MAPBOX_TOKEN}
      initialViewState={{
        longitude: currentLocation[0],
        latitude: currentLocation[1],
        zoom: 13
      }}
      style={{ width: '100%', height: '100%' }}
      mapStyle="mapbox://styles/mapbox/dark-v11"
      onLoad={() => setMapLoaded(true)}
    >
      <NavigationControl position="top-right" />

      {/* Route Line */}
      {mapLoaded && (
        <Source id="route" type="geojson" data={routeGeoJSON as any}>
          <Layer
            id="route-line"
            type="line"
            paint={{
              'line-color': '#F59E0B',
              'line-width': 4,
              'line-opacity': 0.8
            }}
          />
        </Source>
      )}

      {/* Current Location Marker */}
      <Marker longitude={currentLocation[0]} latitude={currentLocation[1]} anchor="center">
        <div className="relative">
          <div className="absolute inset-0 bg-blue-500 rounded-full animate-ping opacity-75 w-16 h-16 -translate-x-1/2 -translate-y-1/2"></div>
          <div className="relative w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-2xl border-4 border-white -translate-x-1/2 -translate-y-1/2">
            <div className="w-4 h-4 bg-white rounded-full"></div>
          </div>
        </div>
      </Marker>

      {/* Destination Marker */}
      <Marker longitude={destination[0]} latitude={destination[1]} anchor="bottom">
        <div className="flex flex-col items-center">
          <div className="w-14 h-14 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-full flex items-center justify-center shadow-2xl border-4 border-white animate-bounce" style={{ animationDuration: '2s' }}>
            <MapPin className="w-7 h-7 text-white" fill="white" />
          </div>
          <div className="mt-2 px-3 py-1 bg-[#F59E0B] text-white text-xs font-bold rounded shadow-lg whitespace-nowrap">
            Destination
          </div>
        </div>
      </Marker>
    </Map>
  );
}