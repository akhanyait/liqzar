import { createBrowserRouter } from "react-router";
import { Dashboard } from "./pages/Dashboard";
import { LiveRoute } from "./pages/LiveRoute";
import { ActiveDeliveries } from "./pages/ActiveDeliveries";
import { Orders } from "./pages/Orders";
import { Stats } from "./pages/Stats";
import { History } from "./pages/History";
import { Drive } from "./pages/Drive";
import { StockVerification } from "./pages/StockVerification";
import { OrderDetails } from "./pages/OrderDetails";
import { DeliveryCompletion } from "./pages/DeliveryCompletion";
import { Notifications } from "./pages/Notifications";
import { Profile } from "./pages/Profile";
import { Permissions } from "./pages/Permissions";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Dashboard,
  },
  {
    path: "/permissions",
    Component: Permissions,
  },
  {
    path: "/live-route",
    Component: LiveRoute,
  },
  {
    path: "/active",
    Component: ActiveDeliveries,
  },
  {
    path: "/orders",
    Component: Orders,
  },
  {
    path: "/stats",
    Component: Stats,
  },
  {
    path: "/history",
    Component: History,
  },
  {
    path: "/drive",
    Component: Drive,
  },
  {
    path: "/verify-stock/:orderId",
    Component: StockVerification,
  },
  {
    path: "/order-details/:orderId",
    Component: OrderDetails,
  },
  {
    path: "/delivery-completion/:orderId",
    Component: DeliveryCompletion,
  },
  {
    path: "/notifications",
    Component: Notifications,
  },
  {
    path: "/profile",
    Component: Profile,
  },
]);