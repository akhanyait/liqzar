import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { BarChart3, TrendingUp, DollarSign, Clock, Star, Award } from "lucide-react";

export function Stats() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-20">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 py-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center shadow-lg">
            <BarChart3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-white text-lg">Statistics</h2>
            <span className="text-xs text-gray-400">This week's performance</span>
          </div>
        </div>
      </div>

      {/* Main Stats */}
      <div className="px-6 space-y-4">
        {/* Earnings */}
        <div className="bg-gradient-to-br from-green-500/20 via-green-600/10 to-transparent backdrop-blur-sm border border-green-500/30 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-xs text-green-400 font-semibold uppercase tracking-wider">Total Earnings</div>
              <div className="text-3xl font-bold text-white">R 8,540</div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-green-500/30">
            <div>
              <div className="text-xs text-gray-400 mb-1">Today</div>
              <div className="text-lg font-bold text-white">R 1,245</div>
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-1">This Week</div>
              <div className="text-lg font-bold text-white">R 8,540</div>
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-1">Average</div>
              <div className="text-lg font-bold text-green-400">R 1,220</div>
            </div>
          </div>
        </div>

        {/* Deliveries */}
        <div className="bg-gradient-to-br from-[#F59E0B]/20 via-[#D97706]/10 to-transparent backdrop-blur-sm border border-[#F59E0B]/30 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-xs text-[#F59E0B] font-semibold uppercase tracking-wider">Deliveries</div>
              <div className="text-3xl font-bold text-white">152</div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 pt-3 border-t border-[#F59E0B]/30">
            <div>
              <div className="text-xs text-gray-400 mb-1">Today</div>
              <div className="text-lg font-bold text-white">8</div>
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-1">This Week</div>
              <div className="text-lg font-bold text-white">152</div>
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-1">Average</div>
              <div className="text-lg font-bold text-[#F59E0B]">21/day</div>
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-3xl p-5 shadow-xl">
          <h3 className="font-bold text-white mb-4 flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-400" />
            Performance Metrics
          </h3>
          
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">On-Time Rate</span>
                <span className="font-bold text-white">96%</span>
              </div>
              <div className="h-2.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] rounded-full" style={{ width: '96%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">Customer Rating</span>
                <span className="font-bold text-white">4.9 / 5.0</span>
              </div>
              <div className="h-2.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full" style={{ width: '98%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">Acceptance Rate</span>
                <span className="font-bold text-white">92%</span>
              </div>
              <div className="h-2.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-green-400 to-green-500 rounded-full" style={{ width: '92%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Time Stats */}
        <div className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-3xl p-5 shadow-xl">
          <h3 className="font-bold text-white mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-400" />
            Time Analysis
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-[#1a1a1a] rounded-2xl p-3">
              <div className="text-xs text-gray-400 mb-1">Avg Delivery Time</div>
              <div className="text-2xl font-bold text-white">22 min</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-2xl p-3">
              <div className="text-xs text-gray-400 mb-1">Total Hours</div>
              <div className="text-2xl font-bold text-white">42.5 hrs</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-2xl p-3">
              <div className="text-xs text-gray-400 mb-1">Online Time</div>
              <div className="text-2xl font-bold text-white">38 hrs</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-2xl p-3">
              <div className="text-xs text-gray-400 mb-1">Break Time</div>
              <div className="text-2xl font-bold text-white">4.5 hrs</div>
            </div>
          </div>
        </div>

        {/* Achievement */}
        <div className="bg-gradient-to-br from-[#F59E0B]/20 via-[#D97706]/10 to-transparent backdrop-blur-sm border border-[#F59E0B]/30 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-2xl flex items-center justify-center shadow-lg">
              <Award className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <div className="font-bold text-white text-lg mb-1">Top Performer</div>
              <div className="text-sm text-[#F59E0B]">Rank #12 this week in Sandton</div>
              <div className="text-xs text-gray-400 mt-1">Keep it up! 💪</div>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
