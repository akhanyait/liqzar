import { useState } from "react";
import { useNavigate } from "react-router";
import { MapPin, Navigation, Bell, Camera, CheckCircle, Shield } from "lucide-react";

export function Permissions() {
  const navigate = useNavigate();
  const [permissions, setPermissions] = useState({
    location: false,
    locationAlways: false,
    notifications: false,
    camera: false
  });

  const [currentStep, setCurrentStep] = useState(0);

  const permissionSteps = [
    {
      id: "location",
      icon: MapPin,
      title: "Location Services",
      description: "Allow LiquorLux to access your location to provide accurate navigation and delivery tracking.",
      details: [
        "Real-time navigation to customers",
        "Optimize delivery routes",
        "Track your delivery progress"
      ],
      required: true,
      color: "from-[#F59E0B] to-[#D97706]"
    },
    {
      id: "locationAlways",
      icon: Navigation,
      title: "Background Location",
      description: "Allow location access even when the app is in the background for continuous navigation.",
      details: [
        "Turn-by-turn navigation",
        "Background route tracking",
        "Automatic arrival detection"
      ],
      required: true,
      color: "from-blue-500 to-blue-600"
    },
    {
      id: "notifications",
      icon: Bell,
      title: "Push Notifications",
      description: "Stay updated with new delivery assignments, route changes, and important alerts.",
      details: [
        "New delivery assignments",
        "Customer messages",
        "Traffic and route updates"
      ],
      required: false,
      color: "from-purple-500 to-purple-600"
    },
    {
      id: "camera",
      icon: Camera,
      title: "Camera Access",
      description: "Use your camera to scan QR codes for stock verification and capture delivery proof.",
      details: [
        "Scan item QR codes",
        "Proof of delivery photos",
        "Verify stock authenticity"
      ],
      required: true,
      color: "from-green-500 to-green-600"
    }
  ];

  const handleRequestPermission = async (permissionId: string) => {
    // Simulate permission request
    setTimeout(() => {
      setPermissions(prev => ({ ...prev, [permissionId]: true }));
      
      // Move to next step
      if (currentStep < permissionSteps.length - 1) {
        setTimeout(() => setCurrentStep(currentStep + 1), 500);
      }
    }, 1000);

    // In a real app, you would request actual permissions here:
    if (permissionId === "location" || permissionId === "locationAlways") {
      // navigator.geolocation.getCurrentPosition()
    } else if (permissionId === "notifications") {
      // Notification.requestPermission()
    } else if (permissionId === "camera") {
      // navigator.mediaDevices.getUserMedia({ video: true })
    }
  };

  const allRequiredGranted = permissionSteps
    .filter(step => step.required)
    .every(step => permissions[step.id as keyof typeof permissions]);

  const handleContinue = () => {
    if (allRequiredGranted) {
      navigate("/");
    }
  };

  const currentPermission = permissionSteps[currentStep];
  const Icon = currentPermission.icon;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] flex flex-col">
      {/* Header */}
      <div className="px-6 py-6">
        <div className="flex items-center justify-between mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div className="text-right">
            <span className="text-sm text-gray-400">Step {currentStep + 1} of {permissionSteps.length}</span>
          </div>
        </div>
        <h1 className="text-3xl font-bold text-white mb-2">App Permissions</h1>
        <p className="text-gray-400">Grant permissions to use all features</p>
      </div>

      {/* Progress Indicator */}
      <div className="px-6 mb-6">
        <div className="flex gap-2">
          {permissionSteps.map((step, index) => (
            <div
              key={step.id}
              className={`flex-1 h-1.5 rounded-full transition-all duration-300 ${
                index <= currentStep
                  ? "bg-gradient-to-r from-[#F59E0B] to-[#D97706]"
                  : "bg-[#2a2a2a]"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 px-6">
        <div className="bg-[#2a2a2a] rounded-3xl p-6 shadow-2xl border border-[#3a3a3a] mb-6">
          {/* Icon */}
          <div className={`w-20 h-20 bg-gradient-to-br ${currentPermission.color} rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg`}>
            <Icon className="w-10 h-10 text-white" />
          </div>

          {/* Title */}
          <div className="text-center mb-4">
            <h2 className="text-2xl font-bold text-white mb-2">
              {currentPermission.title}
            </h2>
            {currentPermission.required && (
              <div className="inline-block bg-red-500/20 border border-red-500/30 px-3 py-1 rounded-full">
                <span className="text-red-400 text-xs font-semibold">Required</span>
              </div>
            )}
          </div>

          {/* Description */}
          <p className="text-gray-400 text-center mb-6">
            {currentPermission.description}
          </p>

          {/* Details */}
          <div className="space-y-3 mb-6">
            {currentPermission.details.map((detail, index) => (
              <div
                key={index}
                className="bg-[#1a1a1a] rounded-xl p-4 flex items-center gap-3"
              >
                <div className={`w-8 h-8 bg-gradient-to-br ${currentPermission.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <span className="text-white text-sm">{detail}</span>
              </div>
            ))}
          </div>

          {/* Permission Status */}
          {permissions[currentPermission.id as keyof typeof permissions] ? (
            <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 rounded-2xl p-4 mb-6">
              <div className="flex items-center justify-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-green-400 font-bold">Permission Granted</span>
              </div>
            </div>
          ) : (
            <button
              onClick={() => handleRequestPermission(currentPermission.id)}
              className={`w-full bg-gradient-to-r ${currentPermission.color} hover:opacity-90 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg mb-4`}
            >
              <Icon className="w-5 h-5" />
              Allow {currentPermission.title}
            </button>
          )}

          {/* Skip button for non-required permissions */}
          {!currentPermission.required && !permissions[currentPermission.id as keyof typeof permissions] && (
            <button
              onClick={() => {
                if (currentStep < permissionSteps.length - 1) {
                  setCurrentStep(currentStep + 1);
                }
              }}
              className="w-full bg-[#1a1a1a] hover:bg-[#252525] text-gray-400 py-3 rounded-xl font-medium transition-all"
            >
              Skip for now
            </button>
          )}
        </div>

        {/* All Permissions Overview */}
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-xl border border-[#3a3a3a] mb-6">
          <h3 className="text-white font-bold mb-4">Permissions Overview</h3>
          <div className="space-y-3">
            {permissionSteps.map((step) => {
              const StepIcon = step.icon;
              const isGranted = permissions[step.id as keyof typeof permissions];
              
              return (
                <div
                  key={step.id}
                  className={`flex items-center justify-between p-3 rounded-xl transition-all ${
                    isGranted ? "bg-green-500/10" : "bg-[#1a1a1a]"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      isGranted ? "bg-green-500/20" : "bg-[#2a2a2a]"
                    }`}>
                      <StepIcon className={`w-4 h-4 ${isGranted ? "text-green-400" : "text-gray-500"}`} />
                    </div>
                    <div>
                      <div className="text-white text-sm font-medium">{step.title}</div>
                      {step.required && (
                        <div className="text-xs text-red-400">Required</div>
                      )}
                    </div>
                  </div>
                  {isGranted ? (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border-2 border-gray-600"></div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="px-6 pb-6 space-y-3">
        {allRequiredGranted && (
          <button
            onClick={handleContinue}
            className="w-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#F59E0B]/30"
          >
            <CheckCircle className="w-5 h-5" />
            Continue to App
          </button>
        )}

        <div className="text-center">
          <p className="text-xs text-gray-500">
            We respect your privacy. You can change these permissions anytime in your device settings.
          </p>
        </div>
      </div>
    </div>
  );
}
