import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { User, Star, Phone, Mail, MapPin, Bell, Shield, HelpCircle, LogOut, ChevronRight, Award } from "lucide-react";
import { useNavigate } from "react-router";

export function Profile() {
  const navigate = useNavigate();

  const driverProfile = {
    name: "James Mbatha",
    phone: "+27 81 234 5678",
    email: "james.mbatha@liquorlux.co.za",
    rating: 4.9,
    totalDeliveries: 487,
    photo: "👨🏾‍💼"
  };

  const settings = [
    {
      category: "Preferences",
      items: [
        { icon: Bell, label: "Notifications", value: "Enabled", action: () => {} },
        { icon: MapPin, label: "Location Services", value: "Always", action: () => navigate("/permissions") }
      ]
    },
    {
      category: "Account",
      items: [
        { icon: Shield, label: "Privacy & Security", action: () => {} },
        { icon: Award, label: "Achievements", action: () => {} },
        { icon: HelpCircle, label: "Help & Support", action: () => {} }
      ]
    }
  ];

  const handleLogout = () => {
    // In real app, this would clear auth tokens
    console.log("Logging out...");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-24">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 py-6">
        <h1 className="text-3xl font-bold text-white mb-1">Profile</h1>
        <p className="text-gray-400 text-sm">Manage your account</p>
      </div>

      {/* Profile Card */}
      <div className="px-6 mb-6">
        <div className="bg-gradient-to-br from-[#2a2a2a] to-[#1f1f1f] rounded-3xl p-6 shadow-2xl border border-[#3a3a3a]">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-full flex items-center justify-center text-4xl shadow-lg">
              {driverProfile.photo}
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-white mb-1">{driverProfile.name}</h2>
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 fill-[#F59E0B] text-[#F59E0B]" />
                <span className="text-white font-bold">{driverProfile.rating}</span>
                <span className="text-gray-400 text-sm">· {driverProfile.totalDeliveries} deliveries</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#1a1a1a] rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Phone className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-400">Phone</span>
              </div>
              <div className="text-white text-sm font-medium">{driverProfile.phone}</div>
            </div>
            <div className="bg-[#1a1a1a] rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Mail className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-400">Email</span>
              </div>
              <div className="text-white text-sm font-medium truncate">{driverProfile.email}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="px-6 mb-6">
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]">
          <h3 className="text-white font-bold mb-4">This Month</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">124</div>
              <div className="text-xs text-gray-400">Deliveries</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[#F59E0B] mb-1">98%</div>
              <div className="text-xs text-gray-400">On-time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-1">4.9</div>
              <div className="text-xs text-gray-400">Rating</div>
            </div>
          </div>
        </div>
      </div>

      {/* Settings */}
      <div className="px-6 mb-6 space-y-6">
        {settings.map((section, idx) => (
          <div key={idx}>
            <h3 className="text-gray-500 text-sm font-semibold uppercase tracking-wider mb-3 px-2">
              {section.category}
            </h3>
            <div className="bg-[#2a2a2a] rounded-3xl overflow-hidden shadow-xl border border-[#3a3a3a]">
              {section.items.map((item, index) => {
                const Icon = item.icon;
                return (
                  <button
                    key={index}
                    onClick={item.action}
                    className="w-full flex items-center justify-between p-5 hover:bg-[#252525] transition-all border-b border-[#3a3a3a] last:border-b-0"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-[#1a1a1a] rounded-xl flex items-center justify-center">
                        <Icon className="w-5 h-5 text-gray-400" />
                      </div>
                      <div className="text-left">
                        <div className="text-white font-medium">{item.label}</div>
                        {item.value && (
                          <div className="text-sm text-gray-400">{item.value}</div>
                        )}
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-600" />
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Logout Button */}
      <div className="px-6 mb-6">
        <button
          onClick={handleLogout}
          className="w-full bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </button>
      </div>

      {/* Footer */}
      <div className="px-6 pb-4 text-center text-xs text-gray-600">
        © 2026 LiquorLux · Developed by Akhanya IT Innovations
      </div>

      <BottomNav />
    </div>
  );
}