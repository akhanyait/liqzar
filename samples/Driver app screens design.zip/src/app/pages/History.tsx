import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { Clock, CheckCircle, MapPin, Package, Calendar } from "lucide-react";

export function History() {
  const historyItems = [
    {
      id: "ORD-2397",
      customer: "David B.",
      address: "15 Sandton Dr, Sandton",
      items: 5,
      date: "Today",
      time: "13:20",
      earnings: "R 310",
      rating: 5
    },
    {
      id: "ORD-2399",
      customer: "Sarah L.",
      address: "92 Jan Smuts Ave, Rosebank",
      items: 3,
      date: "Today",
      time: "13:45",
      earnings: "R 275",
      rating: 5
    },
    {
      id: "ORD-2395",
      customer: "Mike T.",
      address: "34 West St, Sandton",
      items: 2,
      date: "Yesterday",
      time: "16:30",
      earnings: "R 220",
      rating: 4
    },
    {
      id: "ORD-2392",
      customer: "Linda P.",
      address: "78 Katherine St, Sandton",
      items: 6,
      date: "Yesterday",
      time: "15:15",
      earnings: "R 380",
      rating: 5
    },
    {
      id: "ORD-2389",
      customer: "John K.",
      address: "45 Rivonia Rd, Sandton",
      items: 1,
      date: "2 days ago",
      time: "14:00",
      earnings: "R 180",
      rating: 5
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-20">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 py-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center shadow-lg">
            <Clock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-white text-lg">Delivery History</h2>
            <span className="text-xs text-gray-400">152 completed deliveries</span>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-gradient-to-br from-green-500/20 via-green-600/10 to-transparent backdrop-blur-sm border border-green-500/30 rounded-2xl p-4">
            <div className="text-xs text-green-400 mb-1 uppercase tracking-wider font-semibold">This Week</div>
            <div className="text-2xl font-bold text-white mb-1">152</div>
            <div className="text-xs text-gray-400">deliveries</div>
          </div>
          <div className="bg-gradient-to-br from-[#F59E0B]/20 via-[#D97706]/10 to-transparent backdrop-blur-sm border border-[#F59E0B]/30 rounded-2xl p-4">
            <div className="text-xs text-[#F59E0B] mb-1 uppercase tracking-wider font-semibold">Earned</div>
            <div className="text-2xl font-bold text-white mb-1">R 8,540</div>
            <div className="text-xs text-gray-400">this week</div>
          </div>
        </div>
      </div>

      {/* History List */}
      <div className="px-6 space-y-3">
        {historyItems.map((item, index) => (
          <div key={item.id}>
            {(index === 0 || historyItems[index - 1].date !== item.date) && (
              <div className="text-xs text-gray-500 font-semibold uppercase tracking-wider mb-2 mt-4 first:mt-0">
                {item.date}
              </div>
            )}
            <div className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-2xl p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <div className="font-bold text-white">{item.id}</div>
                    <div className="text-gray-400">•</div>
                    <div className="text-gray-300">{item.customer}</div>
                  </div>
                  <div className="flex items-start gap-2 text-sm text-gray-400 mb-3 ml-7">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{item.address}</span>
                  </div>
                </div>
                <div className="text-right ml-4">
                  <div className="font-bold text-green-400 text-lg mb-1">{item.earnings}</div>
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className={`text-xs ${i < item.rating ? 'text-yellow-400' : 'text-gray-600'}`}>★</div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm ml-7">
                <div className="flex items-center gap-4 text-gray-400">
                  <span className="flex items-center gap-1.5">
                    <Package className="w-4 h-4" />
                    {item.items} items
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4" />
                    {item.time}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Load More */}
      <div className="px-6 py-6">
        <button className="w-full bg-[#2a2a2a] hover:bg-[#333333] border border-[#3a3a3a] text-white py-3 rounded-xl font-semibold transition-all">
          Load More
        </button>
      </div>

      <BottomNav />
    </div>
  );
}
