import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { Package, Search, Filter, Calendar } from "lucide-react";

export function Orders() {
  const orders = [
    { id: "ORD-2401", customer: "Thabo M.", status: "pending", time: "14:30", items: 4 },
    { id: "ORD-2400", customer: "Naledi K.", status: "pending", time: "15:00", items: 2 },
    { id: "ORD-2399", customer: "Sarah L.", status: "completed", time: "13:45", items: 3 },
    { id: "ORD-2398", customer: "Priya N.", status: "pending", time: "15:30", items: 1 },
    { id: "ORD-2397", customer: "David B.", status: "completed", time: "13:20", items: 5 },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-20">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 py-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center shadow-lg">
            <Package className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-white text-lg">All Orders</h2>
            <span className="text-xs text-gray-400">8 orders today</span>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="flex gap-3 mb-4">
          <div className="flex-1 bg-[#2a2a2a] rounded-xl px-4 py-3 flex items-center gap-2 border border-[#3a3a3a]">
            <Search className="w-4 h-4 text-gray-500" />
            <input 
              type="text" 
              placeholder="Search orders..." 
              className="bg-transparent text-white text-sm outline-none flex-1 placeholder:text-gray-500"
            />
          </div>
          <button className="bg-[#2a2a2a] border border-[#3a3a3a] rounded-xl px-4 py-3 flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-2xl p-3">
            <div className="text-2xl font-bold text-white mb-1">3</div>
            <div className="text-xs text-gray-400">Pending</div>
          </div>
          <div className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-2xl p-3">
            <div className="text-2xl font-bold text-green-400 mb-1">5</div>
            <div className="text-xs text-gray-400">Completed</div>
          </div>
          <div className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-2xl p-3">
            <div className="text-2xl font-bold text-[#F59E0B] mb-1">8</div>
            <div className="text-xs text-gray-400">Total</div>
          </div>
        </div>
      </div>

      {/* Orders List */}
      <div className="px-6 space-y-3">
        {orders.map((order) => (
          <div
            key={order.id}
            className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-2xl p-4 hover:border-[#F59E0B]/50 transition-all"
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="font-bold text-white mb-1">{order.id}</div>
                <div className="text-sm text-gray-400">{order.customer}</div>
              </div>
              <div className="text-right">
                <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                  order.status === 'completed' 
                    ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                    : 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30'
                }`}>
                  {order.status === 'completed' ? 'Completed' : 'Pending'}
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2 text-gray-400">
                <Calendar className="w-4 h-4" />
                <span>{order.time}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Package className="w-4 h-4" />
                <span>{order.items} items</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <BottomNav />
    </div>
  );
}
