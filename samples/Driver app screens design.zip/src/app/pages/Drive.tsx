import { useEffect, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { ArrowLeft, Phone, Navigation, Clock, MapPin, Package, X, ArrowRight, ArrowUp, Volume2, VolumeX, CornerUpRight, CornerUpLeft } from "lucide-react";
import { useNavigate } from "react-router";

const MAPBOX_TOKEN = "pk.eyJ1IjoiYWtoYW55YWl0IiwiYSI6ImNtbXFyN2wxdzBtMjMycHNiZWJ6OWt5b28ifQ.J2EnpgwudAprvYbMiZCWoQ";

interface NavigationStep {
  instruction: string;
  distance: number;
  duration: number;
  maneuver: {
    type: string;
    modifier?: string;
  };
}

export function Drive() {
  const navigate = useNavigate();
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const driverMarker = useRef<mapboxgl.Marker | null>(null);
  const [loading, setLoading] = useState(true);
  const [eta, setEta] = useState("15");
  const [distance, setDistance] = useState("3.2");
  const [navigationStarted, setNavigationStarted] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [steps, setSteps] = useState<NavigationStep[]>([]);
  const [distanceToNextTurn, setDistanceToNextTurn] = useState(0);
  const speechSynthesisRef = useRef<SpeechSynthesis | null>(null);
  
  // Delivery data
  const delivery = {
    id: "ORD-2401",
    customer: "Thabo M.",
    address: "42 Rivonia Road, Sandton",
    items: 4,
  };

  // Coordinates (example: Johannesburg area)
  const driverLocation: [number, number] = [28.0473, -26.2041]; // Current location
  const destination: [number, number] = [28.0595, -26.1076]; // Destination

  // Function to speak instruction
  const speakInstruction = (text: string) => {
    if (!voiceEnabled || !speechSynthesisRef.current) return;
    
    // Cancel any ongoing speech
    speechSynthesisRef.current.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 1;
    speechSynthesisRef.current.speak(utterance);
  };

  // Get maneuver icon
  const getManeuverIcon = (type: string, modifier?: string) => {
    if (type === "turn" && modifier === "right") return CornerUpRight;
    if (type === "turn" && modifier === "left") return CornerUpLeft;
    if (type === "arrive") return MapPin;
    return ArrowUp;
  };

  // Format distance
  const formatDistance = (meters: number) => {
    if (meters < 1000) {
      return `${Math.round(meters)} m`;
    }
    return `${(meters / 1000).toFixed(1)} km`;
  };

  // Start navigation
  const startNavigation = () => {
    setNavigationStarted(true);
    if (steps.length > 0) {
      speakInstruction(`Navigation started. ${steps[0].instruction}`);
      
      // Simulate step progression
      let stepIndex = 0;
      const intervalId = setInterval(() => {
        stepIndex++;
        if (stepIndex >= steps.length) {
          clearInterval(intervalId);
          speakInstruction("You have arrived at your destination");
          return;
        }
        
        setCurrentStepIndex(stepIndex);
        speakInstruction(steps[stepIndex].instruction);
        
        // Update distance to next turn
        setDistanceToNextTurn(steps[stepIndex].distance);
      }, 8000); // Change step every 8 seconds for demo
      
      return () => clearInterval(intervalId);
    }
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      speechSynthesisRef.current = window.speechSynthesis;
    }
  }, []);

  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    mapboxgl.accessToken = MAPBOX_TOKEN;

    // Initialize map
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/navigation-night-v1",
      center: driverLocation,
      zoom: 13,
      pitch: 60,
      bearing: -17.6,
      attributionControl: false,
    });

    map.current.on("load", async () => {
      if (!map.current) return;

      try {
        // Fetch route from Mapbox Directions API with steps
        const response = await fetch(
          `https://api.mapbox.com/directions/v5/mapbox/driving/${driverLocation[0]},${driverLocation[1]};${destination[0]},${destination[1]}?geometries=geojson&overview=full&steps=true&banner_instructions=true&voice_instructions=true&voice_units=metric&access_token=${MAPBOX_TOKEN}`
        );
        const data = await response.json();

        if (data.routes && data.routes[0]) {
          const route = data.routes[0];
          const duration = Math.round(route.duration / 60);
          const dist = (route.distance / 1000).toFixed(1);
          
          setEta(duration.toString());
          setDistance(dist);

          // Extract navigation steps
          const navigationSteps: NavigationStep[] = route.legs[0].steps.map((step: any) => ({
            instruction: step.maneuver.instruction,
            distance: step.distance,
            duration: step.duration,
            maneuver: {
              type: step.maneuver.type,
              modifier: step.maneuver.modifier,
            },
          }));
          
          setSteps(navigationSteps);
          setDistanceToNextTurn(navigationSteps[0]?.distance || 0);

          // Add route line
          map.current!.addSource("route", {
            type: "geojson",
            data: {
              type: "Feature",
              properties: {},
              geometry: route.geometry,
            },
          });

          map.current!.addLayer({
            id: "route",
            type: "line",
            source: "route",
            layout: {
              "line-join": "round",
              "line-cap": "round",
            },
            paint: {
              "line-color": "#F59E0B",
              "line-width": 6,
              "line-opacity": 0.9,
            },
          });

          // Add route outline
          map.current!.addLayer({
            id: "route-outline",
            type: "line",
            source: "route",
            layout: {
              "line-join": "round",
              "line-cap": "round",
            },
            paint: {
              "line-color": "#D97706",
              "line-width": 8,
              "line-opacity": 0.5,
            },
          }, "route");

          // Fit map to show entire route
          const coordinates = route.geometry.coordinates;
          const bounds = coordinates.reduce(
            (bounds: mapboxgl.LngLatBounds, coord: [number, number]) => {
              return bounds.extend(coord as [number, number]);
            },
            new mapboxgl.LngLatBounds(coordinates[0], coordinates[0])
          );

          map.current!.fitBounds(bounds, {
            padding: { top: 220, bottom: 320, left: 50, right: 50 },
            duration: 1000,
          });
        }

        // Create custom driver marker (car icon)
        const driverEl = document.createElement("div");
        driverEl.className = "driver-marker";
        driverEl.innerHTML = `
          <div style="
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #F59E0B, #D97706);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 20px rgba(245, 158, 11, 0.5);
            border: 3px solid white;
          ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5 17H4C3.44772 17 3 16.5523 3 16V12.5858C3 12.3207 3.10536 12.0664 3.29289 11.8789L6.58579 8.58579C6.96086 8.21071 7.46957 8 8 8H16C16.5304 8 17.0391 8.21071 17.4142 8.58579L20.7071 11.8789C20.8946 12.0664 21 12.3207 21 12.5858V16C21 16.5523 20.5523 17 20 17H19M5 17C5 18.1046 5.89543 19 7 19C8.10457 19 9 18.1046 9 17M5 17C5 15.8954 5.89543 15 7 15C8.10457 15 9 15.8954 9 17M19 17C19 18.1046 18.1046 19 17 19C15.8954 19 15 18.1046 15 17M19 17C19 15.8954 18.1046 15 17 15C15.8954 15 15 15.8954 15 17M9 17H15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        `;

        driverMarker.current = new mapboxgl.Marker({ element: driverEl })
          .setLngLat(driverLocation)
          .addTo(map.current!);

        // Create custom destination marker
        const destEl = document.createElement("div");
        destEl.className = "destination-marker";
        destEl.innerHTML = `
          <div style="
            width: 44px;
            height: 44px;
            background: #DC2626;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 20px rgba(220, 38, 38, 0.5);
            border: 3px solid white;
          ">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: rotate(45deg);">
              <path d="M5 10H19" stroke="white" stroke-width="2" stroke-linecap="round"/>
              <path d="M5 14H19" stroke="white" stroke-width="2" stroke-linecap="round"/>
              <path d="M5 6H19C20.1046 6 21 6.89543 21 8V16C21 17.1046 20.1046 18 19 18H5C3.89543 18 3 17.1046 3 16V8C3 6.89543 3.89543 6 5 6Z" stroke="white" stroke-width="2"/>
            </svg>
          </div>
        `;

        new mapboxgl.Marker({ element: destEl })
          .setLngLat(destination)
          .addTo(map.current!);

        setLoading(false);
      } catch (error) {
        console.error("Error loading map:", error);
        setLoading(false);
      }
    });

    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    // Update distance countdown when navigation is active
    if (navigationStarted && steps[currentStepIndex]) {
      let currentDistance = steps[currentStepIndex].distance;
      const decrementInterval = setInterval(() => {
        currentDistance -= 50; // Decrease by 50 meters every second
        if (currentDistance < 0) currentDistance = 0;
        setDistanceToNextTurn(currentDistance);
      }, 1000);

      return () => clearInterval(decrementInterval);
    }
  }, [navigationStarted, currentStepIndex, steps]);

  const currentStep = steps[currentStepIndex];
  const ManeuverIcon = currentStep ? getManeuverIcon(currentStep.maneuver.type, currentStep.maneuver.modifier) : ArrowUp;

  return (
    <div className="relative h-screen w-full bg-[#1a1a1a]">
      {/* Map Container */}
      <div ref={mapContainer} className="absolute inset-0 w-full h-full" />

      {/* Loading Overlay */}
      {loading && (
        <div className="absolute inset-0 bg-[#1a1a1a] flex items-center justify-center z-10">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-[#F59E0B] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-white font-medium">Loading navigation...</p>
          </div>
        </div>
      )}

      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-[#1a1a1a] via-[#1a1a1a]/95 to-transparent p-4 z-20">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate("/active")}
            className="w-11 h-11 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center hover:bg-white/20 transition-all border border-white/20"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>

          <div className="flex-1 mx-3 bg-white/10 backdrop-blur-md rounded-xl px-4 py-2.5 border border-white/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#F59E0B]" />
                  <div>
                    <div className="text-xs text-gray-400">ETA</div>
                    <div className="text-sm font-bold text-white">{eta} min</div>
                  </div>
                </div>
                <div className="w-px h-8 bg-white/20"></div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#F59E0B]" />
                  <div>
                    <div className="text-xs text-gray-400">Distance</div>
                    <div className="text-sm font-bold text-white">{distance} km</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => navigate("/active")}
            className="w-11 h-11 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center hover:bg-white/20 transition-all border border-white/20"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Recenter Button */}
      <button
        onClick={() => {
          if (map.current) {
            map.current.flyTo({
              center: driverLocation,
              zoom: 14,
              pitch: 60,
              bearing: -17.6,
              duration: 1500,
            });
          }
        }}
        className="absolute right-4 top-24 w-12 h-12 bg-white rounded-xl shadow-lg flex items-center justify-center hover:bg-gray-100 transition-all z-20"
      >
        <Navigation className="w-5 h-5 text-[#1a1a1a]" />
      </button>

      {/* Voice Toggle Button */}
      <button
        onClick={() => setVoiceEnabled(!voiceEnabled)}
        className="absolute right-4 top-36 w-12 h-12 bg-white/10 backdrop-blur-md rounded-xl shadow-lg flex items-center justify-center hover:bg-white/20 transition-all z-20 border border-white/20"
      >
        {voiceEnabled ? <Volume2 className="w-5 h-5 text-white" /> : <VolumeX className="w-5 h-5 text-white" />}
      </button>

      {/* Navigation Instructions Banner */}
      {navigationStarted && currentStep && (
        <div className="absolute top-24 left-4 right-20 bg-gradient-to-r from-[#F59E0B] to-[#D97706] rounded-2xl p-4 shadow-2xl border border-[#F59E0B] z-20 animate-slide-down">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
              <ManeuverIcon className="w-8 h-8 text-white" strokeWidth={2.5} />
            </div>
            <div className="flex-1">
              <div className="text-white/80 text-xs font-semibold uppercase tracking-wide mb-1">
                In {formatDistance(distanceToNextTurn)}
              </div>
              <div className="text-white text-base font-bold leading-tight">
                {currentStep.instruction}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Start Navigation Button */}
      {!navigationStarted && !loading && steps.length > 0 && (
        <div className="absolute top-24 left-4 right-4 bg-gradient-to-r from-[#2a2a2a] to-[#1a1a1a] rounded-2xl p-4 shadow-2xl border border-[#3a3a3a] z-20">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center">
              <Navigation className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <div className="text-white text-sm font-bold">Ready to navigate</div>
              <div className="text-gray-400 text-xs">Tap to start voice guidance</div>
            </div>
          </div>
          <button
            onClick={startNavigation}
            className="w-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#F59E0B]/30"
          >
            <Volume2 className="w-5 h-5" />
            Start Navigation
          </button>
        </div>
      )}

      {/* Bottom Delivery Info Card */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/98 to-transparent p-4 pb-6 z-20">
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]">
          {/* Order ID Badge */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-[#F59E0B] rounded-full animate-pulse"></div>
              <span className="text-xs text-gray-400 uppercase tracking-wider font-semibold">
                En Route
              </span>
            </div>
            <div className="bg-[#1a1a1a] px-3 py-1.5 rounded-full">
              <span className="text-sm font-bold text-white">{delivery.id}</span>
            </div>
          </div>

          {/* Customer Info */}
          <div className="mb-4">
            <div className="text-2xl font-bold text-white mb-1">{delivery.customer}</div>
            <div className="flex items-start gap-2 text-gray-400">
              <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-[#F59E0B]" />
              <span className="text-sm">{delivery.address}</span>
            </div>
          </div>

          {/* Items Count */}
          <div className="flex items-center gap-2 mb-4 bg-[#1a1a1a] rounded-xl px-4 py-3">
            <Package className="w-5 h-5 text-[#F59E0B]" />
            <div className="flex-1">
              <div className="text-xs text-gray-400">Items to deliver</div>
              <div className="text-lg font-bold text-white">{delivery.items} items</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button className="bg-[#1a1a1a] hover:bg-[#252525] text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all border border-[#3a3a3a]">
              <Phone className="w-5 h-5" />
              Call Customer
            </button>
            <button 
              onClick={() => navigate("/delivery-completion/ORD-2401")}
              className="bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#F59E0B]/30"
            >
              <Package className="w-5 h-5" />
              Mark Delivered
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}