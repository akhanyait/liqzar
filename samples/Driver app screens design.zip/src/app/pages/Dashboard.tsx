import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { Package, MapPin, Navigation, Clock, Truck, QrCode, CheckCircle, Car, Route, MapPinned } from "lucide-react";
import { useNavigate, useLocation } from "react-router";
import { useState, useEffect } from "react";

export function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const [verifiedDeliveries, setVerifiedDeliveries] = useState<string[]>([]);
  const [showVerifiedBanner, setShowVerifiedBanner] = useState(false);
  const [lastVerifiedOrder, setLastVerifiedOrder] = useState<string>("");

  // Listen for verified orders coming back from stock verification
  useEffect(() => {
    if (location.state?.verifiedOrder) {
      const orderId = location.state.verifiedOrder;
      setVerifiedDeliveries(prev => {
        if (!prev.includes(orderId)) {
          return [...prev, orderId];
        }
        return prev;
      });
      setLastVerifiedOrder(orderId);
      setShowVerifiedBanner(true);
      
      // Hide banner after 5 seconds
      setTimeout(() => setShowVerifiedBanner(false), 5000);
      
      // Clear the state
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const driverName = "James";
  const currentDate = new Date().toLocaleDateString("en-US", { 
    weekday: "long", 
    month: "long", 
    day: "numeric" 
  });

  const stats = {
    totalDeliveries: 8,
    totalItems: 24,
    totalKm: 45.6,
    estimatedFinish: "3:30 PM"
  };

  const activeDeliveries = [
    {
      id: "ORD-2401",
      customer: "Thabo M.",
      address: "42 Rivonia Road, Sandton",
      items: 4,
      eta: "15 min",
      km: "3.2 km",
      status: "ready",
      verified: verifiedDeliveries.includes("ORD-2401")
    },
    {
      id: "ORD-2400",
      customer: "Naledi K.",
      address: "12 Oxford Rd, Rosebank",
      items: 2,
      eta: "35 min",
      km: "5.2 km",
      status: "pending",
      verified: verifiedDeliveries.includes("ORD-2400")
    }
  ];

  const pendingAssignments = [
    {
      id: "ORD-2398",
      customer: "Priya N.",
      address: "88 Umhlanga Rocks Dr",
      items: 1,
      eta: "1 hr",
      km: "12.8 km"
    }
  ];

  const handleVerifyStock = (orderId: string) => {
    navigate(`/verify-stock/${orderId}`);
  };

  const handleStartDriving = (orderId: string) => {
    navigate("/drive");
  };

  const handleAcceptDelivery = (orderId: string) => {
    // In real app, this would call an API
    console.log("Accepting delivery:", orderId);
  };

  const handleViewDetails = (orderId: string) => {
    navigate(`/order-details/${orderId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-24">
      <StatusBar />
      
      {/* Stock Verified Success Banner */}
      {showVerifiedBanner && (
        <div className="fixed top-20 left-0 right-0 z-50 px-6 animate-in slide-in-from-top duration-300">
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-4 shadow-2xl border border-green-400">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-white flex-shrink-0" />
              <div className="flex-1">
                <div className="text-white font-bold">Stock Verified Successfully!</div>
                <div className="text-green-100 text-sm">
                  {lastVerifiedOrder} is ready for delivery
                </div>
              </div>
              <button
                onClick={() => setShowVerifiedBanner(false)}
                className="text-white hover:text-green-100 transition-colors"
              >
                ✕
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Welcome Header */}
      <div className="px-6 py-6">
        <h1 className="text-3xl font-bold text-white mb-1">
          Good morning, {driverName}
        </h1>
        <p className="text-gray-400 text-sm">{currentDate}</p>
      </div>

      {/* Day Snapshot Card */}
      <div className="px-6 mb-6">
        <div className="bg-gradient-to-br from-[#2a2a2a] to-[#1f1f1f] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]">
          <h3 className="text-white font-bold mb-4 flex items-center gap-2">
            <Truck className="w-5 h-5 text-[#F59E0B]" />
            Today's Overview
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-[#1a1a1a] rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Car className="w-4 h-4 text-[#F59E0B]" />
                <span className="text-xs text-gray-400">Deliveries</span>
              </div>
              <div className="text-2xl font-bold text-white">{stats.totalDeliveries}</div>
            </div>

            <div className="bg-[#1a1a1a] rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Package className="w-4 h-4 text-[#F59E0B]" />
                <span className="text-xs text-gray-400">Items</span>
              </div>
              <div className="text-2xl font-bold text-white">{stats.totalItems}</div>
            </div>

            <div className="bg-[#1a1a1a] rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Route className="w-4 h-4 text-[#F59E0B]" />
                <span className="text-xs text-gray-400">Distance</span>
              </div>
              <div className="text-2xl font-bold text-white">{stats.totalKm} km</div>
            </div>

            <div className="bg-[#1a1a1a] rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-[#F59E0B]" />
                <span className="text-xs text-gray-400">Finish</span>
              </div>
              <div className="text-2xl font-bold text-white">{stats.estimatedFinish}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Active Deliveries */}
      <div className="px-6 mb-6">
        <h2 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
          <MapPinned className="w-5 h-5 text-[#F59E0B]" />
          Active Deliveries
        </h2>

        <div className="space-y-4">
          {activeDeliveries.map((delivery) => (
            <div
              key={delivery.id}
              className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="text-lg font-bold text-white">{delivery.id}</div>
                  {delivery.verified && (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  )}
                </div>
                <div className={`px-3 py-1.5 rounded-full text-xs font-bold ${
                  delivery.status === "ready" 
                    ? "bg-green-500/20 text-green-400" 
                    : "bg-yellow-500/20 text-yellow-400"
                }`}>
                  {delivery.status === "ready" ? "Ready" : "Pending"}
                </div>
              </div>

              {/* Stock Verification Status */}
              <div className={`mb-4 rounded-2xl p-4 border-2 ${
                delivery.verified 
                  ? "bg-green-500/10 border-green-500/40" 
                  : "bg-orange-500/10 border-orange-500/40"
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {delivery.verified ? (
                      <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
                        <CheckCircle className="w-6 h-6 text-white" />
                      </div>
                    ) : (
                      <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center">
                        <QrCode className="w-6 h-6 text-white" />
                      </div>
                    )}
                    <div>
                      <div className="text-xs text-gray-400 mb-1">Stock Status</div>
                      <div className={`text-lg font-bold ${
                        delivery.verified ? "text-green-400" : "text-orange-400"
                      }`}>
                        {delivery.verified ? "CONFIRMED" : "PENDING VERIFICATION"}
                      </div>
                    </div>
                  </div>
                  {delivery.verified && (
                    <div className="text-right">
                      <div className="text-xs text-green-400 mb-1">All Items</div>
                      <div className="text-lg font-bold text-green-400">✓ Scanned</div>
                    </div>
                  )}
                </div>
              </div>

              {/* Customer Info */}
              <div className="mb-4">
                <div className="text-xl font-bold text-white mb-2">{delivery.customer}</div>
                <div className="flex items-start gap-2 text-gray-400 mb-3">
                  <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-[#F59E0B]" />
                  <span className="text-sm">{delivery.address}</span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <span className="flex items-center gap-1.5">
                    <Package className="w-4 h-4" />
                    {delivery.items} items
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4" />
                    {delivery.eta}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Navigation className="w-4 h-4" />
                    {delivery.km}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                {!delivery.verified && (
                  <div className="bg-blue-500/20 border border-blue-500/30 rounded-xl p-3 flex items-start gap-2 mb-2">
                    <QrCode className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                    <p className="text-blue-300 text-xs">
                      Verify stock by scanning all items before starting delivery
                    </p>
                  </div>
                )}

                <button
                  onClick={() => handleViewDetails(delivery.id)}
                  className="w-full bg-[#1a1a1a] hover:bg-[#252525] text-white py-3 rounded-xl font-bold transition-all border border-[#3a3a3a]"
                >
                  View Order Details
                </button>

                {!delivery.verified ? (
                  <button
                    onClick={() => handleVerifyStock(delivery.id)}
                    className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg"
                  >
                    <QrCode className="w-5 h-5" />
                    Verify Stock
                  </button>
                ) : (
                  <>
                    <div className="bg-green-500/20 border border-green-500/30 rounded-xl p-3 flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                      <p className="text-green-300 text-xs">
                        Stock verified! You can now start driving to the customer
                      </p>
                    </div>
                    <button
                      onClick={() => handleStartDriving(delivery.id)}
                      className="w-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#F59E0B]/30"
                    >
                      <Navigation className="w-5 h-5" />
                      Start Driving
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pending Assignments */}
      {pendingAssignments.length > 0 && (
        <div className="px-6 mb-6">
          <h2 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-gray-400" />
            Pending Assignments
          </h2>

          <div className="space-y-3">
            {pendingAssignments.map((delivery) => (
              <div
                key={delivery.id}
                className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-2xl p-4"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="font-bold text-white">{delivery.id}</div>
                      <div className="text-gray-400">•</div>
                      <div className="text-gray-300">{delivery.customer}</div>
                    </div>
                    <div className="flex items-start gap-2 text-sm text-gray-400 mb-3">
                      <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <span>{delivery.address}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <span className="flex items-center gap-1.5">
                        <Package className="w-4 h-4" />
                        {delivery.items} items
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Navigation className="w-4 h-4" />
                        {delivery.km}
                      </span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => handleAcceptDelivery(delivery.id)}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white py-3 rounded-xl font-bold transition-all"
                >
                  Accept Delivery
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="px-6 pb-4 text-center text-xs text-gray-600">
        © 2026 LiquorLux · Developed by Akhanya IT Innovations
      </div>

      <BottomNav />
    </div>
  );
}