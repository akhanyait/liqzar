import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { CheckCircle, Star, ArrowLeft, MessageSquare, Camera, Upload } from "lucide-react";

export function DeliveryCompletion() {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const [rating, setRating] = useState(0);
  const [notes, setNotes] = useState("");
  const [photoUploaded, setPhotoUploaded] = useState(false);

  const handleComplete = () => {
    // In real app, this would submit to API
    setTimeout(() => {
      navigate("/", { state: { completedOrder: orderId } });
    }, 500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a]">
      {/* Header */}
      <div className="bg-[#1a1a1a] px-6 py-4 flex items-center gap-4 border-b border-[#3a3a3a]">
        <button
          onClick={() => navigate("/drive")}
          className="w-10 h-10 bg-[#2a2a2a] rounded-xl flex items-center justify-center hover:bg-[#3a3a3a] transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div>
          <h1 className="text-xl font-bold text-white">Complete Delivery</h1>
          <p className="text-sm text-gray-400">Order {orderId || "ORD-2401"}</p>
        </div>
      </div>

      {/* Success Animation */}
      <div className="px-6 py-8">
        <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 rounded-3xl p-8 border border-green-500/30 text-center mb-6">
          <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-green-500/30">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Delivery Completed!</h2>
          <p className="text-green-400">Great job! Time to finalize the delivery.</p>
        </div>

        {/* Photo Upload */}
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a] mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Camera className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-white font-bold">Proof of Delivery</h3>
              <p className="text-sm text-gray-400">Upload delivery photo</p>
            </div>
          </div>

          {!photoUploaded ? (
            <button
              onClick={() => setPhotoUploaded(true)}
              className="w-full bg-gradient-to-br from-[#2a2a2a] to-[#1f1f1f] border-2 border-dashed border-[#3a3a3a] rounded-2xl p-8 hover:border-blue-500/50 transition-all"
            >
              <Upload className="w-12 h-12 text-gray-600 mx-auto mb-3" />
              <div className="text-gray-400 text-sm">Tap to upload photo</div>
            </button>
          ) : (
            <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 rounded-2xl p-4 border border-green-500/30 flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-400" />
              <div>
                <div className="text-white font-medium">Photo uploaded</div>
                <div className="text-sm text-green-400">delivery_proof.jpg</div>
              </div>
            </div>
          )}
        </div>

        {/* Rate Customer */}
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a] mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center">
              <Star className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-white font-bold">Rate Customer</h3>
              <p className="text-sm text-gray-400">How was your experience?</p>
            </div>
          </div>

          <div className="flex items-center justify-center gap-3 bg-[#1a1a1a] rounded-2xl py-6">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => setRating(star)}
                className="transition-transform hover:scale-110"
              >
                <Star
                  className={`w-10 h-10 ${
                    star <= rating
                      ? "fill-[#F59E0B] text-[#F59E0B]"
                      : "text-gray-600"
                  }`}
                />
              </button>
            ))}
          </div>

          {rating > 0 && (
            <div className="mt-4 text-center">
              <span className="text-white font-medium">
                {rating === 5 && "Excellent! ⭐"}
                {rating === 4 && "Great! 👍"}
                {rating === 3 && "Good 👌"}
                {rating === 2 && "Okay 🤔"}
                {rating === 1 && "Poor 😕"}
              </span>
            </div>
          )}
        </div>

        {/* Notes */}
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a] mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-white font-bold">Delivery Notes</h3>
              <p className="text-sm text-gray-400">Optional feedback</p>
            </div>
          </div>

          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add any notes about the delivery..."
            className="w-full bg-[#1a1a1a] text-white rounded-xl p-4 border border-[#3a3a3a] focus:border-[#F59E0B] focus:outline-none resize-none h-32"
          />
          <div className="mt-2 text-right text-xs text-gray-500">
            {notes.length}/500 characters
          </div>
        </div>

        {/* Complete Button */}
        <button
          onClick={handleComplete}
          disabled={!photoUploaded || rating === 0}
          className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
            photoUploaded && rating > 0
              ? "bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] shadow-lg shadow-[#F59E0B]/30"
              : "bg-[#2a2a2a] text-gray-500 cursor-not-allowed"
          }`}
        >
          <CheckCircle className="w-5 h-5" />
          Complete Delivery
        </button>

        {(!photoUploaded || rating === 0) && (
          <p className="text-center text-sm text-gray-500 mt-3">
            {!photoUploaded && "Upload photo"}
            {!photoUploaded && rating === 0 && " and "}
            {rating === 0 && "rate customer"} to complete
          </p>
        )}
      </div>
    </div>
  );
}
