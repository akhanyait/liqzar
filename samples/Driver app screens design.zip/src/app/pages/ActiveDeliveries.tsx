import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { Navigation, MapPin, Package, Clock, Zap, TrendingUp, Phone, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router";

export function ActiveDeliveries() {
  const navigate = useNavigate();
  const upcomingDeliveries = [
    {
      id: "ORD-2400",
      customer: "Naledi K.",
      address: "12 Oxford Rd, Rosebank",
      items: 2,
      distance: "35 min",
      distanceKm: "5.2 km",
    },
    {
      id: "ORD-2398",
      customer: "Priya N.",
      address: "88 Umhlanga Rocks Dr",
      items: 1,
      distance: "1 hr",
      distanceKm: "12.8 km",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-20">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 py-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center shadow-lg">
            <Package className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-white text-lg">Active Deliveries</h2>
            <span className="text-xs text-gray-400">3 deliveries in queue</span>
          </div>
        </div>
      </div>

      {/* Next Delivery - Hero Card */}
      <div className="px-6 mb-6">
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-gray-400 uppercase tracking-wider font-semibold">Up Next</span>
            <div className="flex items-center gap-1.5 bg-[#F59E0B] text-[#1a1a1a] px-3 py-1.5 rounded-full text-xs font-bold">
              <Zap className="w-3.5 h-3.5" />
              Smart ETA
              <span className="ml-1 bg-[#D97706] text-white px-2 py-0.5 rounded-full">15 min</span>
            </div>
          </div>

          <div className="mb-4">
            <div className="text-2xl font-bold text-white mb-1">ORD-2401</div>
            <div className="text-gray-400 text-lg">Thabo M.</div>
          </div>

          <div className="flex items-start gap-2 mb-4 text-white">
            <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0 text-gray-400" />
            <span className="font-medium text-gray-300">42 Rivonia Road, Sandton</span>
          </div>

          <div className="flex items-center gap-6 mb-4 text-gray-400">
            <span className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              <span className="font-medium">4 items</span>
            </span>
            <span className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <span className="font-medium">3.2 km</span>
            </span>
          </div>

          <div className="bg-[#1a1a1a] rounded-2xl p-4 mb-4 space-y-2">
            <div className="flex items-center justify-between text-white">
              <span className="text-sm text-gray-400">Drive time</span>
              <span className="font-bold">12 min</span>
            </div>
            <div className="flex items-center justify-between text-white">
              <span className="text-sm text-gray-400">Traffic delay</span>
              <span className="font-bold text-red-400">+2 min</span>
            </div>
            <div className="flex items-center justify-between text-white">
              <span className="text-sm text-gray-400">Handoff</span>
              <span className="font-bold text-green-400">-1 min</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button className="bg-[#1a1a1a] hover:bg-[#252525] text-white py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all border border-[#3a3a3a]">
              <Phone className="w-4 h-4" />
              Call
            </button>
            <button 
              onClick={() => navigate("/drive")}
              className="bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg"
            >
              <Navigation className="w-4 h-4" />
              Start Trip
            </button>
          </div>
        </div>
      </div>

      {/* Upcoming Deliveries */}
      <div className="px-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-gray-400" />
          <h3 className="font-bold text-white">Coming Up</h3>
          <span className="text-xs text-gray-500">({upcomingDeliveries.length})</span>
        </div>

        <div className="space-y-3">
          {upcomingDeliveries.map((delivery, index) => (
            <div
              key={delivery.id}
              className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] rounded-2xl p-4 hover:border-[#F59E0B]/50 transition-all group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-6 h-6 bg-[#1a1a1a] text-gray-400 rounded-lg flex items-center justify-center text-xs font-bold">
                      {index + 2}
                    </span>
                    <div className="font-bold text-white">{delivery.id}</div>
                    <div className="text-gray-400">•</div>
                    <div className="text-gray-300">{delivery.customer}</div>
                  </div>
                  <div className="flex items-start gap-2 text-sm text-gray-400 mb-3">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{delivery.address}</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span className="flex items-center gap-1.5">
                      <Package className="w-4 h-4" />
                      {delivery.items} items
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-4 h-4" />
                      {delivery.distanceKm}
                    </span>
                  </div>
                </div>
                <div className="text-right ml-4">
                  <div className="font-bold text-white text-lg mb-1">{delivery.distance}</div>
                  <ArrowRight className="w-5 h-5 text-gray-600 group-hover:text-[#F59E0B] transition-colors ml-auto" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Today's Performance */}
      <div className="px-6 mb-6">
        <div className="bg-gradient-to-br from-[#F59E0B]/20 via-[#D97706]/10 to-transparent backdrop-blur-sm border border-[#F59E0B]/30 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-lg flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-bold text-white">Today's Performance</h3>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">On-time Rate</span>
                <span className="font-bold text-white">96%</span>
              </div>
              <div className="h-2.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] rounded-full" style={{ width: '96%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">Customer Rating</span>
                <span className="font-bold text-white">4.9 / 5.0</span>
              </div>
              <div className="h-2.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] rounded-full" style={{ width: '98%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">Delivery Speed</span>
                <span className="font-bold text-white">Avg 22 min</span>
              </div>
              <div className="h-2.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-green-400 to-green-500 rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 pb-4 text-center text-xs text-gray-600">
        © 2026 LiquorLux · Developed by Akhanya IT Innovations
      </div>

      <BottomNav />
    </div>
  );
}