import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { Bell, Package, CheckCircle, AlertCircle, MessageSquare, TrendingUp } from "lucide-react";
import { useState, useEffect } from "react";
import { useNotifications } from "../context/NotificationContext";

export function Notifications() {
  const { setUnreadCount } = useNotifications();
  
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: "assignment",
      icon: Package,
      title: "New Delivery Assignment",
      message: "ORD-2401 assigned to you - 4 items to deliver",
      time: "5 min ago",
      read: false,
      color: "from-[#F59E0B] to-[#D97706]"
    },
    {
      id: 2,
      type: "success",
      icon: CheckCircle,
      title: "Delivery Completed",
      message: "ORD-2399 successfully delivered to Sarah P.",
      time: "1 hour ago",
      read: false,
      color: "from-green-500 to-green-600"
    },
    {
      id: 3,
      type: "update",
      icon: MessageSquare,
      title: "Customer Message",
      message: "Thabo M. sent delivery instructions for ORD-2401",
      time: "2 hours ago",
      read: false,
      color: "from-blue-500 to-blue-600"
    },
    {
      id: 4,
      type: "alert",
      icon: AlertCircle,
      title: "Route Update",
      message: "Traffic detected on N1 highway - rerouting suggested",
      time: "3 hours ago",
      read: true,
      color: "from-red-500 to-red-600"
    },
    {
      id: 5,
      type: "achievement",
      icon: TrendingUp,
      title: "Daily Goal Achieved!",
      message: "You've completed 8 deliveries today - Great work!",
      time: "4 hours ago",
      read: true,
      color: "from-purple-500 to-purple-600"
    },
    {
      id: 6,
      type: "assignment",
      icon: Package,
      title: "New Assignment Available",
      message: "ORD-2398 ready for acceptance - 1 item",
      time: "5 hours ago",
      read: true,
      color: "from-[#F59E0B] to-[#D97706]"
    }
  ]);

  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    // Mark all as read after viewing the page
    const timer = setTimeout(() => {
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
    }, 2000);

    return () => clearTimeout(timer);
  }, [setUnreadCount]);

  const handleMarkAsRead = (id: number) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
    const newUnreadCount = notifications.filter(n => !n.read && n.id !== id).length;
    setUnreadCount(newUnreadCount);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-24">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 py-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1 flex items-center gap-3">
              <Bell className="w-8 h-8 text-[#F59E0B]" />
              Notifications
            </h1>
            <p className="text-gray-400 text-sm">
              {unreadCount > 0 ? `${unreadCount} unread messages` : "All caught up!"}
            </p>
          </div>
          {unreadCount > 0 && (
            <div className="w-10 h-10 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-full flex items-center justify-center">
              <span className="text-white font-bold">{unreadCount}</span>
            </div>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="px-6 space-y-3">
        {notifications.map((notification) => {
          const Icon = notification.icon;
          return (
            <div
              key={notification.id}
              className={`rounded-3xl p-5 shadow-xl transition-all ${
                notification.read
                  ? "bg-[#2a2a2a]/60 border border-[#3a3a3a]"
                  : "bg-[#2a2a2a] border border-[#F59E0B]/30"
              }`}
            >
              <div className="flex gap-4">
                <div className={`w-12 h-12 bg-gradient-to-br ${notification.color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-white font-bold">{notification.title}</h3>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-[#F59E0B] rounded-full"></div>
                    )}
                  </div>
                  <p className="text-gray-400 text-sm mb-3">{notification.message}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">{notification.time}</span>
                    {!notification.read && (
                      <button className="text-xs text-[#F59E0B] font-semibold hover:text-[#D97706] transition-colors" onClick={() => handleMarkAsRead(notification.id)}>
                        Mark as read
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty State (if no notifications) */}
      {notifications.length === 0 && (
        <div className="px-6 py-16 text-center">
          <div className="w-24 h-24 bg-[#2a2a2a] rounded-full flex items-center justify-center mx-auto mb-4">
            <Bell className="w-12 h-12 text-gray-600" />
          </div>
          <h3 className="text-white font-bold text-xl mb-2">No notifications</h3>
          <p className="text-gray-400">You're all caught up!</p>
        </div>
      )}

      {/* Footer */}
      <div className="px-6 pt-8 pb-4 text-center text-xs text-gray-600">
        © 2026 LiquorLux · Developed by Akhanya IT Innovations
      </div>

      <BottomNav />
    </div>
  );
}