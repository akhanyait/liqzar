import { StatusBar } from "../components/StatusBar";
import { BottomNav } from "../components/BottomNav";
import { MapWrapper } from "../components/MapWrapper";
import { Navigation, MapPin, Clock, Package, Zap, Phone } from "lucide-react";
import { Link } from "react-router";

export function LiveRoute() {
  // Sandton coordinates (example)
  const currentLocation: [number, number] = [28.0473, -26.1076];
  const destination: [number, number] = [28.0553, -26.1016];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-20">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center shadow-lg">
            <Navigation className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-white text-lg">Live Route</h2>
            <span className="text-xs text-gray-400">Optimized by AI</span>
          </div>
        </div>
        <span className="px-3 py-1.5 bg-green-500/20 border border-green-500/30 text-green-400 text-xs font-bold rounded-full flex items-center gap-1.5">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          LIVE
        </span>
      </div>

      {/* Map Section */}
      <div className="mx-6 mb-6 rounded-3xl overflow-hidden shadow-2xl" style={{ height: '320px' }}>
        <MapWrapper 
          currentLocation={currentLocation}
          destination={destination}
        />
      </div>

      {/* AI Route Optimization */}
      <div className="px-6 mb-6">
        <div className="bg-gradient-to-br from-[#F59E0B]/20 via-[#D97706]/10 to-transparent backdrop-blur-sm border border-[#F59E0B]/30 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-bold text-white">AI Optimization</h3>
            <span className="px-2 py-0.5 bg-[#F59E0B]/20 text-[#F59E0B] text-xs font-bold rounded-full">
              SMART
            </span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-[#2a2a2a]/50 rounded-2xl p-3">
              <div className="text-xs text-gray-400 mb-1">Total Route</div>
              <div className="text-2xl font-bold text-white">18.4 km</div>
            </div>
            <div className="bg-[#2a2a2a]/50 rounded-2xl p-3">
              <div className="text-xs text-gray-400 mb-1">Est. Time</div>
              <div className="text-2xl font-bold text-white">1h 45m</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#F59E0B]/30">
            <div>
              <div className="text-xs text-gray-400 mb-1">Saved</div>
              <div className="text-xl font-bold text-green-400">2.1 km</div>
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-2">Efficiency</div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2.5 bg-[#1a1a1a] rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] rounded-full" style={{ width: '87%' }}></div>
                </div>
                <span className="text-sm font-bold text-white">87%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Next Delivery Card */}
      <div className="px-6 mb-6">
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-gray-400 uppercase tracking-wider font-semibold">Next Delivery</span>
            <div className="flex items-center gap-1.5 bg-[#F59E0B] text-[#1a1a1a] px-3 py-1.5 rounded-full text-xs font-bold">
              <Zap className="w-3.5 h-3.5" />
              Smart ETA
              <span className="ml-1 bg-[#D97706] text-white px-2 py-0.5 rounded-full">15 min</span>
            </div>
          </div>

          <div className="mb-4">
            <div className="text-2xl font-bold text-white mb-1">ORD-2401</div>
            <div className="text-gray-400 text-lg">Thabo M.</div>
          </div>

          <div className="flex items-start gap-2 mb-4 text-white">
            <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0 text-gray-400" />
            <span className="font-medium text-gray-300">42 Rivonia Road, Sandton</span>
          </div>

          <div className="flex items-center gap-6 mb-4 text-gray-400">
            <span className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              <span className="font-medium">4 items</span>
            </span>
            <span className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <span className="font-medium">3.2 km</span>
            </span>
          </div>

          <div className="bg-[#1a1a1a] rounded-2xl p-4 mb-4 space-y-2">
            <div className="flex items-center justify-between text-white">
              <span className="text-sm text-gray-400">Drive time</span>
              <span className="font-bold">12 min</span>
            </div>
            <div className="flex items-center justify-between text-white">
              <span className="text-sm text-gray-400">Traffic delay</span>
              <span className="font-bold text-red-400">+2 min</span>
            </div>
            <div className="flex items-center justify-between text-white">
              <span className="text-sm text-gray-400">Handoff</span>
              <span className="font-bold text-green-400">-1 min</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button className="bg-[#1a1a1a] hover:bg-[#252525] text-white py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all border border-[#3a3a3a]">
              <Phone className="w-4 h-4" />
              Call
            </button>
            <button className="bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg">
              <Navigation className="w-4 h-4" />
              Start Navigation
            </button>
          </div>
        </div>
      </div>

      {/* Upcoming Preview */}
      <div className="px-6 pb-4">
        <Link 
          to="/active" 
          className="bg-[#2a2a2a]/80 backdrop-blur-sm border border-[#3a3a3a] hover:border-[#F59E0B]/50 rounded-2xl p-4 flex items-center justify-between group transition-all"
        >
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-gray-400" />
            <div>
              <div className="font-semibold text-white">View All Deliveries</div>
              <div className="text-sm text-gray-400">2 more after this</div>
            </div>
          </div>
          <Navigation className="w-5 h-5 text-gray-500 group-hover:text-[#F59E0B] transition-colors" />
        </Link>
      </div>

      <BottomNav />
    </div>
  );
}