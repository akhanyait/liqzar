import { useNavigate, useParams, useLocation } from "react-router";
import { ArrowLeft, User, MapPin, Phone, Package, DollarSign, FileText, Wine, Beer, QrCode, CheckCircle } from "lucide-react";
import { useState, useEffect } from "react";

export function OrderDetails() {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const location = useLocation();
  const [isVerified, setIsVerified] = useState(false);

  // Check if this order is verified
  useEffect(() => {
    // In a real app, this would check against backend state
    // For now, check localStorage or route state
    const verified = location.state?.verified || false;
    setIsVerified(verified);
  }, [location.state]);

  const orderData = {
    id: orderId || "ORD-2401",
    customer: {
      name: "Thabo M.",
      phone: "+27 82 456 7890",
      address: "42 Rivonia Road, Sandton",
      instructions: "Please ring doorbell. Gate code: 1234"
    },
    items: [
      {
        name: "Premium Whiskey",
        image: "🥃",
        quantity: 2,
        price: 450.00
      },
      {
        name: "Red Wine",
        image: "🍷",
        quantity: 1,
        price: 220.00
      },
      {
        name: "Craft Beer Pack (6)",
        image: "🍺",
        quantity: 1,
        price: 180.00
      }
    ],
    total: 1300.00,
    status: "Ready for delivery"
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a] pb-6">
      {/* Header */}
      <div className="bg-[#1a1a1a] px-6 py-4 flex items-center gap-4 border-b border-[#3a3a3a] sticky top-0 z-10">
        <button
          onClick={() => navigate("/")}
          className="w-10 h-10 bg-[#2a2a2a] rounded-xl flex items-center justify-center hover:bg-[#3a3a3a] transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div>
          <h1 className="text-xl font-bold text-white">Order Details</h1>
          <p className="text-sm text-gray-400">{orderData.id}</p>
        </div>
      </div>

      {/* Status Badge */}
      <div className="px-6 py-4">
        <div className="bg-green-500/20 border border-green-500/30 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-green-400 font-bold">{orderData.status}</span>
          </div>
        </div>
      </div>

      {/* Customer Info */}
      <div className="px-6 mb-6">
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold">Customer Information</h2>
              <p className="text-sm text-gray-400">Contact details</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-[#1a1a1a] rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <User className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-400">Name</span>
              </div>
              <div className="text-white font-medium">{orderData.customer.name}</div>
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <Phone className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-400">Phone</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-white font-medium">{orderData.customer.phone}</div>
                <a
                  href={`tel:${orderData.customer.phone}`}
                  className="bg-gradient-to-r from-[#F59E0B] to-[#D97706] text-[#1a1a1a] px-4 py-2 rounded-lg font-bold text-sm hover:from-[#D97706] hover:to-[#F59E0B] transition-all"
                >
                  Call
                </a>
              </div>
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-400">Delivery Address</span>
              </div>
              <div className="text-white font-medium">{orderData.customer.address}</div>
            </div>

            <div className="bg-gradient-to-r from-blue-500/10 to-blue-600/5 border border-blue-500/20 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <FileText className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-blue-400">Delivery Instructions</span>
              </div>
              <div className="text-white text-sm">{orderData.customer.instructions}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Order Items */}
      <div className="px-6 mb-6">
        <div className="bg-[#2a2a2a] rounded-3xl p-5 shadow-2xl border border-[#3a3a3a]">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold">Order Items</h2>
              <p className="text-sm text-gray-400">{orderData.items.length} items</p>
            </div>
          </div>

          <div className="space-y-3">
            {orderData.items.map((item, index) => (
              <div
                key={index}
                className="bg-[#1a1a1a] rounded-xl p-4 flex items-center gap-4"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#2a2a2a] to-[#1f1f1f] rounded-xl flex items-center justify-center text-3xl border border-[#3a3a3a]">
                  {item.image}
                </div>
                <div className="flex-1">
                  <div className="text-white font-bold mb-1">{item.name}</div>
                  <div className="text-sm text-gray-400">Qty: {item.quantity}</div>
                </div>
                <div className="text-right">
                  <div className="text-white font-bold">R{item.price.toFixed(2)}</div>
                  <div className="text-xs text-gray-400">per item</div>
                </div>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="mt-4 pt-4 border-t border-[#3a3a3a]">
            <div className="flex items-center justify-between bg-gradient-to-r from-[#F59E0B]/20 to-[#D97706]/10 rounded-xl p-4 border border-[#F59E0B]/30">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-[#F59E0B]" />
                <span className="text-white font-bold">Order Total</span>
              </div>
              <span className="text-2xl font-bold text-white">R{orderData.total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-6 space-y-3">
        {isVerified ? (
          <div className="flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <span className="text-green-400 font-bold">Stock Verified</span>
          </div>
        ) : (
          <button
            onClick={() => navigate("/verify-stock/" + orderId)}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white py-4 rounded-xl font-bold transition-all shadow-lg"
          >
            Verify Stock
          </button>
        )}
        <button
          onClick={() => navigate("/")}
          className="w-full bg-[#2a2a2a] hover:bg-[#3a3a3a] text-white py-4 rounded-xl font-bold transition-all border border-[#3a3a3a]"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}