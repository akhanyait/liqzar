import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { ArrowLeft, QrCode, Package, CheckCircle, Camera, AlertCircle } from "lucide-react";

interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  scannedCount: number;
  image: string;
}

export function StockVerification() {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const [scanning, setScanning] = useState(false);
  const [currentScanItem, setCurrentScanItem] = useState<string | null>(null);
  const [verified, setVerified] = useState(false);

  const [orderItems, setOrderItems] = useState<OrderItem[]>([
    { id: "item-1", name: "Premium Whiskey", quantity: 2, scannedCount: 0, image: "🥃" },
    { id: "item-2", name: "Red Wine", quantity: 1, scannedCount: 0, image: "🍷" },
    { id: "item-3", name: "Craft Beer Pack", quantity: 1, scannedCount: 0, image: "🍺" }
  ]);

  const totalRequired = orderItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalScanned = orderItems.reduce((sum, item) => sum + item.scannedCount, 0);
  const allItemsScanned = orderItems.every(item => item.scannedCount === item.quantity);

  const handleStartScan = (itemId: string) => {
    setCurrentScanItem(itemId);
    setScanning(true);
    
    // Simulate QR code scan after 2 seconds
    setTimeout(() => {
      handleItemScanned(itemId);
    }, 2000);
  };

  const handleItemScanned = (itemId: string) => {
    setOrderItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId && item.scannedCount < item.quantity
          ? { ...item, scannedCount: item.scannedCount + 1 }
          : item
      )
    );
    setScanning(false);
    setCurrentScanItem(null);
  };

  const handleVerifyComplete = () => {
    setVerified(true);
    setTimeout(() => {
      navigate("/", { state: { verifiedOrder: orderId } });
    }, 1500);
  };

  const handleResetItem = (itemId: string) => {
    setOrderItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId ? { ...item, scannedCount: 0 } : item
      )
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a1a] via-[#171717] to-[#1a1a1a]">
      {/* Header */}
      <div className="bg-[#1a1a1a] px-6 py-4 flex items-center gap-4 border-b border-[#3a3a3a] sticky top-0 z-30">
        <button
          onClick={() => navigate("/")}
          className="w-10 h-10 bg-[#2a2a2a] rounded-xl flex items-center justify-center hover:bg-[#3a3a3a] transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-white">Stock Verification</h1>
          <p className="text-sm text-gray-400">Order {orderId}</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-400">Progress</div>
          <div className="text-lg font-bold text-white">{totalScanned}/{totalRequired}</div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="px-6 py-4">
        <div className="bg-[#2a2a2a] rounded-full h-3 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-[#F59E0B] to-[#D97706] h-full transition-all duration-500 rounded-full"
            style={{ width: `${(totalScanned / totalRequired) * 100}%` }}
          ></div>
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-xs text-gray-500">Scan each item</span>
          <span className="text-xs text-[#F59E0B] font-bold">
            {Math.round((totalScanned / totalRequired) * 100)}%
          </span>
        </div>
      </div>

      {/* Scanning Modal */}
      {scanning && currentScanItem && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-[#1a1a1a] rounded-3xl p-6 max-w-sm w-full border border-[#3a3a3a]">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <QrCode className="w-8 h-8 text-white animate-pulse" />
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Scanning QR Code</h3>
              <p className="text-gray-400 text-sm">
                Position the QR code within the frame
              </p>
            </div>

            {/* Scanner Frame */}
            <div className="relative aspect-square bg-gradient-to-br from-[#2a2a2a] to-[#1f1f1f] rounded-2xl overflow-hidden mb-4">
              <div className="absolute inset-0 border-4 border-dashed border-blue-500/50 rounded-2xl animate-pulse"></div>
              
              {/* Corner markers */}
              <div className="absolute top-4 left-4 w-8 h-8 border-l-4 border-t-4 border-blue-500"></div>
              <div className="absolute top-4 right-4 w-8 h-8 border-r-4 border-t-4 border-blue-500"></div>
              <div className="absolute bottom-4 left-4 w-8 h-8 border-l-4 border-b-4 border-blue-500"></div>
              <div className="absolute bottom-4 right-4 w-8 h-8 border-r-4 border-b-4 border-blue-500"></div>

              {/* Scanning line animation */}
              <div className="absolute inset-x-4 top-1/2 h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse"></div>
              
              <div className="absolute inset-0 flex items-center justify-center">
                <Camera className="w-12 h-12 text-gray-600" />
              </div>
            </div>

            <button
              onClick={() => {
                setScanning(false);
                setCurrentScanItem(null);
              }}
              className="w-full bg-[#2a2a2a] text-white py-3 rounded-xl font-medium"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Items List */}
      <div className="px-6 pb-6 space-y-3">
        <h2 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
          <Package className="w-5 h-5 text-[#F59E0B]" />
          Scan Items ({totalScanned}/{totalRequired})
        </h2>

        {orderItems.map((item) => {
          const isComplete = item.scannedCount === item.quantity;
          const inProgress = item.scannedCount > 0 && item.scannedCount < item.quantity;
          
          return (
            <div
              key={item.id}
              className={`rounded-3xl p-5 shadow-xl border transition-all ${
                isComplete
                  ? "bg-gradient-to-br from-green-500/20 to-green-600/10 border-green-500/30"
                  : "bg-[#2a2a2a] border-[#3a3a3a]"
              }`}
            >
              <div className="flex items-start gap-4 mb-4">
                {/* Item Image */}
                <div className={`w-16 h-16 rounded-xl flex items-center justify-center text-3xl border-2 ${
                  isComplete ? "bg-green-500/20 border-green-500/50" : "bg-[#1a1a1a] border-[#3a3a3a]"
                }`}>
                  {item.image}
                </div>

                {/* Item Info */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-white font-bold">{item.name}</h3>
                      <p className="text-sm text-gray-400">Required: {item.quantity}</p>
                    </div>
                    {isComplete && (
                      <CheckCircle className="w-6 h-6 text-green-400" />
                    )}
                  </div>

                  {/* Scan Progress */}
                  <div className="bg-[#1a1a1a] rounded-xl p-3 mb-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-400">Scanned</span>
                      <span className={`text-sm font-bold ${
                        isComplete ? "text-green-400" : inProgress ? "text-[#F59E0B]" : "text-gray-500"
                      }`}>
                        {item.scannedCount} / {item.quantity}
                      </span>
                    </div>
                    <div className="bg-[#2a2a2a] rounded-full h-2 overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-300 rounded-full ${
                          isComplete ? "bg-green-500" : "bg-[#F59E0B]"
                        }`}
                        style={{ width: `${(item.scannedCount / item.quantity) * 100}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    {!isComplete ? (
                      <button
                        onClick={() => handleStartScan(item.id)}
                        disabled={scanning}
                        className={`flex-1 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                          scanning
                            ? "bg-[#1a1a1a] text-gray-500 cursor-not-allowed"
                            : "bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-lg"
                        }`}
                      >
                        <QrCode className="w-5 h-5" />
                        Scan Item
                      </button>
                    ) : (
                      <div className="flex-1 bg-green-500/20 border border-green-500/30 text-green-400 py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                        <CheckCircle className="w-5 h-5" />
                        Complete
                      </div>
                    )}
                    
                    {item.scannedCount > 0 && (
                      <button
                        onClick={() => handleResetItem(item.id)}
                        className="px-4 py-3 bg-[#1a1a1a] hover:bg-[#252525] text-gray-400 rounded-xl font-medium transition-all border border-[#3a3a3a]"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Verification Status */}
      <div className="px-6 pb-6 sticky bottom-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a] to-transparent pt-4">
        {!allItemsScanned && totalScanned < totalRequired && (
          <div className="bg-blue-500/20 border border-blue-500/30 rounded-2xl p-4 mb-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
            <div>
              <div className="text-blue-400 font-bold text-sm mb-1">Scan Required</div>
              <div className="text-blue-300 text-xs">
                Please scan all items to verify stock before starting delivery
              </div>
            </div>
          </div>
        )}

        {!verified ? (
          <button
            onClick={handleVerifyComplete}
            disabled={!allItemsScanned}
            className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
              allItemsScanned
                ? "bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#F59E0B] text-[#1a1a1a] shadow-lg shadow-[#F59E0B]/30"
                : "bg-[#2a2a2a] text-gray-500 cursor-not-allowed"
            }`}
          >
            <CheckCircle className="w-5 h-5" />
            {allItemsScanned ? "Confirm Stock Verification" : `Scan ${totalRequired - totalScanned} more items`}
          </button>
        ) : (
          <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 rounded-2xl p-6 border border-green-500/30">
            <div className="text-center">
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <div className="text-2xl font-bold text-white mb-2">Stock Verified!</div>
              <div className="text-green-400">All items scanned successfully</div>
              <div className="text-sm text-gray-400 mt-2">Redirecting to dashboard...</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}