
  # Driver app screens design

  This is a code bundle for Driver app screens design. The original project is available at https://www.figma.com/design/HWBMGCAfQ0f2IcqOmZFGkk/Driver-app-screens-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  